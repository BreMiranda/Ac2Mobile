package com.example.ac2_treinos;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

import com.example.ac2_treinos.DBHelper;
import com.example.ac2_treinos.R;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private DBHelper dbHelper;
    private ListView exerciseListView;
    private Button startButton;
    private TextView timerText, currentExerciseText;
    private ArrayAdapter<String> adapter;
    private List<String> exercises;
    private int currentExerciseIndex = 0;
    private CountDownTimer countDownTimer;
    private long timeLeftInMillis;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DBHelper(this);
        exerciseListView = findViewById(R.id.exercise_list);
        startButton = findViewById(R.id.start_button);
        timerText = findViewById(R.id.timer_text);
        currentExerciseText = findViewById(R.id.current_exercise);

        exercises = dbHelper.getAllExercises();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, exercises);
        exerciseListView.setAdapter(adapter);

        startButton.setOnClickListener(v -> startWorkout());


        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Exercise Channel";
            String description = "Canal para notificações de treino";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel("exercise_channel", name, importance);
            channel.setDescription(description);

            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
            }
        }

        Button openCadastroButton = findViewById(R.id.open_cadastro_button);
        openCadastroButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, CadastroActivity.class);
            startActivity(intent);
        });

    }

    private void startWorkout() {
        if (exercises.isEmpty()) {
            Toast.makeText(this, "Nenhum exercício cadastrado!", Toast.LENGTH_SHORT).show();
            return;
        }

        currentExerciseIndex = 0;
        nextExercise();
    }

    private void nextExercise() {
        if (currentExerciseIndex >= exercises.size()) {
            finishWorkout();
            return;
        }

        String exercise = exercises.get(currentExerciseIndex);
        String[] parts = exercise.split(" - ");
        String name = parts[0];
        int duration = Integer.parseInt(parts[1].replace("s", ""));

        currentExerciseText.setText(name);
        timeLeftInMillis = duration * 1000;
        startTimer();

        sendNotification("Iniciando exercício", name);

        currentExerciseIndex++;
    }

    private void startTimer() {
        countDownTimer = new CountDownTimer(timeLeftInMillis, 1000) {

            @Override
            public void onTick(long millisUntilFinished) {
                timeLeftInMillis = millisUntilFinished;
                updateTimer();
            }

            @Override
            public void onFinish() {
                nextExercise();
            }
        }.start();
    }

    private void updateTimer() {
        int minutes = (int) (timeLeftInMillis / 1000) / 60;
        int seconds = (int) (timeLeftInMillis / 1000) % 60;
        String timeLeftText = String.format("%02d:%02d", minutes, seconds);
        timerText.setText(timeLeftText);
    }

    private void sendNotification(String title, String message) {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "exercise_channel")
                .setSmallIcon(R.drawable.ic_launcher_foreground)
                .setContentTitle(title)
                .setContentText(message)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true);

        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        notificationManager.notify(1, builder.build());
    }

    private void finishWorkout() {
        sendNotification("Treino concluído!", "Parabéns, você terminou seu treino!");
        Toast.makeText(this, "Treino Concluído! Parabéns!", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permissão para notificações concedida", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Permissão para notificações negada", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
