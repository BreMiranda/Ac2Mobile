package com.example.ac2_treinos;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class CadastroActivity extends AppCompatActivity {

    private EditText exerciseNameEditText, exerciseDurationEditText;
    private Button saveButton;
    private DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);

        dbHelper = new DBHelper(this);
        exerciseNameEditText = findViewById(R.id.exercise_name);
        exerciseDurationEditText = findViewById(R.id.exercise_duration);
        saveButton = findViewById(R.id.save_button);

        saveButton.setOnClickListener(v -> saveExercise());
    }

    private void saveExercise() {
        String name = exerciseNameEditText.getText().toString().trim();
        String durationStr = exerciseDurationEditText.getText().toString().trim();

        if (name.isEmpty() || durationStr.isEmpty()) {
            Toast.makeText(this, "Por favor, preencha todos os campos.", Toast.LENGTH_SHORT).show();
            return;
        }

        int duration = Integer.parseInt(durationStr);

        dbHelper.addExercise(name, duration);

        Toast.makeText(this, "Exercício salvo com sucesso!", Toast.LENGTH_SHORT).show();

        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish();
    }
}
